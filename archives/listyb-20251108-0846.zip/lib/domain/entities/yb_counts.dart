class YbCounts {
  final int total;
  final int active;
  final int done;

  const YbCounts({
    required this.total,
    required this.active,
    required this.done,
  });
}
