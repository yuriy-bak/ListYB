// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'items_dao.dart';

// ignore_for_file: type=lint
mixin _$ItemsDaoMixin on DatabaseAccessor<AppDatabase> {
  $ListsTableTable get listsTable => attachedDatabase.listsTable;
  $ItemsTableTable get itemsTable => attachedDatabase.itemsTable;
}
