// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lists_dao.dart';

// ignore_for_file: type=lint
mixin _$ListsDaoMixin on DatabaseAccessor<AppDatabase> {
  $ListsTableTable get listsTable => attachedDatabase.listsTable;
  $ItemsTableTable get itemsTable => attachedDatabase.itemsTable;
}
