# Validation Rules
- List.title: trim, 1..100 chars
- Item.title: trim, 1..200 chars
- Reject empty titles; trim spaces
- Errors: map to l10n messages